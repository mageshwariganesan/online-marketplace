CREATE DATABASE IF NOT EXISTS online_stock;
USE online_stock;

-- Create users table with larger data types for unlimited storage
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,   -- Username remains unique
    password VARCHAR(255) NOT NULL,           -- Password field
    email TEXT NOT NULL                      -- Email can now be longer (use TEXT for unlimited length)
    
);

-- Create products table with larger text for description and larger precision for price
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,                     -- Foreign key to users table
    name VARCHAR(255) NOT NULL,                -- Product name
    description TEXT,                         -- Description can be longer with TEXT
    price DECIMAL(15, 2) NOT NULL,             -- Price with more precision (up to 15 digits)
    stock INT NOT NULL,                       -- Stock quantity
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE  -- Foreign key relationship with users table
);

-- Inserting initial users (Ensure unique usernames)
INSERT INTO users (username, password, email)
VALUES
    ('john_doe', 'password123', 'john@example.com'),
    ('jane_smith', 'password456', 'jane@example.com');

-- Example of inserting a new user manually:
INSERT INTO users (username, password, email)
VALUES
    ('saranya', 'mypassword', 'saranya@example.com'); -- New user added

-- Example of adding another user:
INSERT INTO users (username, password, email)
VALUES
    ('alex', 'securepass', 'alex@example.com'); -- Another new user added

-- Inserting products (More can be added later, no changes needed for unlimited products)
INSERT INTO products (user_id, name, description, price, stock)
VALUES
    (2, 'Laptop', 'A high-performance laptop with a powerful processor', 999.99, 10),
    (2, 'Smartphone', 'Latest model smartphone with AI camera', 499.99, 5),
    (2, 'Headphones', 'Noise-canceling headphones with deep bass', 199.99, 20),
    (3, 'Tablet', 'An ultra-light tablet with high-resolution display', 299.99, 15),
    (3, 'Smartwatch', 'Wearable technology to track fitness and health', 129.99, 30);

-- Check all users and products (You can run these queries to see data)
SELECT * FROM products;
SELECT * FROM users;

commit;
